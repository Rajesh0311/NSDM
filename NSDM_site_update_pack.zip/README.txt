
NSDM site update package
========================

Copy these files into C:\Users\Rajesh\dev\nsdm:

- index.html
- research.html
- papers.html
- use-cases.html
- verticals.html
- governance.html
- action-states.html
- assets\site.css

Keep the existing:
- tools.html
- favicon.svg
- assets\nsdm_decision_boundary_hero_2.png
- assets\nsdm_institute_topology.png

Preview:
python -m http.server 8080
Open:
http://localhost:8080/index.html?v=nsdm2
